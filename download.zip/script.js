function goToQR() {
  const mobile = document.getElementById("mobile").value.trim();
  const pass = document.getElementById("login-password").value.trim();

  if (mobile === "" || pass === "") {
    alert("Please enter both mobile number and password.");
    return;
  }

  // You can change this login password as needed
  document.getElementById("login-page").classList.add("hidden");
  document.getElementById("qr-page").classList.remove("hidden");
}

function goToConfirmation() {
  document.getElementById("qr-page").classList.add("hidden");
  document.getElementById("confirm-page").classList.remove("hidden");
}

function verifyPassword() {
  const password = document.getElementById("final-password").value.trim();
  const correctPassword = "richpoint999";

  if (password === correctPassword) {
    document.getElementById("confirm-page").classList.add("hidden");
    document.getElementById("final-page").classList.remove("hidden");
    document.getElementById("error").textContent = "";
  } else {
    document.getElementById("error").textContent = "Incorrect password. Please check your mobile.";
  }
}

function buyCoins() {
  const count = document.getElementById("coin-count").value;
  document.getElementById("purchase-confirmation").textContent = `You have successfully purchased ${count} Rich Coins!`;
}